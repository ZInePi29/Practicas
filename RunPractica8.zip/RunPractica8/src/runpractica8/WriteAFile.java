/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package runpractica8;

/**
 *
 * @author denze
 */

import java.io.*;

public class WriteAFile {
    
    public WriteAFile(String fileN){
        this.wfiles(fileN);
    }
    
    
    private void wfiles(String fileN){
        
        try
        {
            FileWriter fw = new FileWriter(fileN);
            fw.write("Esto es una prueb");
            fw.write(97);
            fw.close();
            
            FileReader fr = new FileReader(fileN);
            
            int valor = fr.read();
            
            while(valor!=-1){
                System.out.print((char)valor);
                valor=fr.read();
            }
            
            fr.close();
        }
        catch(IOException ex){
            
            System.out.println(ex.getMessage());
            
        }
        finally
        {
            
        }
        
    }
    
}
