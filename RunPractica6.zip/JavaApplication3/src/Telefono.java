/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author eulal
 */
public class Telefono extends ComponenteElectronico implements IOtrosComponentesE{

    @Override
    public String encender() {
        return "Telefono encendido";
    }

    @Override
    public String apagar() {
        return "Telefono apagado";
    }
    
    public String hacerLlamada(){
        return "Digite el numero a marcar";
    }
    
    public void llamando(double x){
        System.out.println("Llamando al: " + x);
    }
}
