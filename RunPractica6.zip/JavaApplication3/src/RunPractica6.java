
import java.util.ArrayList;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author eulal
 */
public class RunPractica6 {
    static Scanner pal = new Scanner (System.in);
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String mod;
        String mar;
        double x;
// TODO code application logic here
        ArrayList<Telefono> tl = new ArrayList<>(2);
        Telefono nuevo = new Telefono();
        
        tl.add(nuevo);
        x=0;
        for(Telefono o: tl){
            System.out.println("Ingresa la marca del telefono");
            mar = pal.next();
            o.setMarca(mar);
            System.out.println("Ingresa el modelo del telefono");
            mod = pal.next();
            o.setModelo(mod);
            System.out.println(o.hacerLlamada());
            x = pal.nextDouble();
        }
        
        for(Telefono o: tl){
            System.out.println(o.encender());
            System.out.println(o.getMarca());
            System.out.println(o.getModelo());
            o.llamando(x);
        }
        
        ArrayList<Computadora> cp = new ArrayList<>(2);
        Computadora nueva = new Computadora();
        String u;
        String c;
        cp.add(nueva);
        u = "hola";
        for(Computadora o: cp){
            System.out.println("Ingresa la marca de la computadora");
            mar = pal.next();
            o.setMarca(mar);
            System.out.println("Ingresa el modelo de la computadora");
            mod = pal.next();
            o.setModelo(mod);
            System.out.println(o.usuario());
            u = pal.next();
            System.out.println(o.contraseña());
            c = pal.next();
        }
        for(Computadora o: cp){
            System.out.println(o.encender());
            System.out.println(o.getMarca());
            System.out.println(o.getModelo());
            o.bienvenida(u);
        }
        
    }
    
}
