/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author eulal
 */
public class Computadora extends ComponenteElectronico implements IOtrosComponentesE{

    @Override
    public String encender() {
        return "Computadora encendida";
    }

    @Override
    public String apagar() {
        return "Computadora apagada";
    }
    
    public String usuario(){
        return "Ingresa tu usuario";
    }
    
    public String contraseña(){
        return "Ingresa tu contraseña";
    }
    
    public void bienvenida(String usuario){
        System.out.println("Bienvenid@ " + usuario);
    }
    
}
