/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package runpractica7;

import java.util.Scanner;
/**
 *
 * @author denze
 */
public class RunPractica7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner x = new Scanner(System.in);
        
        int n;
        double caminar;
        double total = 0;
        String pal;
        
        Gato montes = new Gato();
        Perro dalmata = new Perro();
        Gorrion albino = new Gorrion();
        Cocodrilo lago = new Cocodrilo();
        Jaguar rey = new Jaguar();
        
        System.out.println("Haremos una lista de animales\n");
        
        System.out.println("Dame la edad del gato: ");
        n = x.nextInt();
        montes.setEdad(n);
        System.out.println("Dame el nombre del gato: ");
        pal = x.next();
        montes.setNombre(pal);
        System.out.println("Dame cuánto caminó el gato: ");
        caminar = x.nextDouble();
        System.out.println(montes.caminar(caminar));
        
        total = total + caminar;
        
        System.out.println("Dame la edad del perro: ");
        n = x.nextInt();
        dalmata.setEdad(n);
        System.out.println("Dame el nombre del perro: ");
        pal = x.next();
        dalmata.setNombre(pal);
        System.out.println("Dame cuánto caminó el perro: ");
        caminar = x.nextDouble();
        System.out.println(dalmata.caminar(caminar));
        
        total = total + caminar;
        
        System.out.println("Dame la edad del gorrion: ");
        n = x.nextInt();
        albino.setEdad(n);
        System.out.println("Dame el nombre del gorrion: ");
        pal = x.next();
        albino.setNombre(pal);
        System.out.println("Dame cuánto voló el gorrión: ");
        caminar = x.nextDouble();
        System.out.println(albino.caminar(caminar));
        
        total = total + caminar;
        
        System.out.println("Dame la edad del cocodrilo: ");
        n = x.nextInt();
        lago.setEdad(n);
        System.out.println("Dame el nombre del cocodrilo: ");
        pal = x.next();
        lago.setNombre(pal);
        System.out.println("Dame cuánto caminó el cocodrilo: ");
        caminar = x.nextDouble();
        System.out.println(lago.caminar(caminar));
        
        total = total + caminar;
        
        System.out.println("Dame la edad del jaguar: ");
        n = x.nextInt();
        rey.setEdad(n);
        System.out.println("Dame el nombre del jaguar: ");
        pal = x.next();
        rey.setNombre(pal);
        System.out.println("Dame cuánto caminó el jaguar: ");
        caminar = x.nextDouble();
        System.out.println(rey.caminar(caminar));
        
        total = total + caminar;
        
        total = total/5;
        
        System.out.println("El promedio fue: ");
        System.out.println(total);
    }
    
}
