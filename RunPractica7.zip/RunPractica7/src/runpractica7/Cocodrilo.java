/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package runpractica7;

/**
 *
 * @author denze
 */
public class Cocodrilo extends Animal{
   

    @Override
    public String caminar(double caminar) {
        if(caminar>100){
            return "El cocodriló "+getNombre()+" caminó más de 100 metros";
        }else{
           return "El cocodrilo "+getNombre()+" caminó de 100 metros";
        }
    }


}
