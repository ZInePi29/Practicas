/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package runpractica7;

/**
 *
 * @author denze
 */
public class Jaguar extends Animal{
    private String raza;
    
    public String maullar(){
        return "Los jaguares maullan";
    }

    @Override
    public String caminar(double caminar) {
        if(caminar>100){
            return "El jaguar "+getNombre()+" caminó más de 100 metros";
        }else{
           return "El jaguar "+getNombre()+" caminó menos de 100 metros";
        }
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

}
