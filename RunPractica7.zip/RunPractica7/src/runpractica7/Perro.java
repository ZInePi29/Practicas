/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package runpractica7;

/**
 *
 * @author denze
 */
public class Perro extends Animal{
    private String color;
    
    public String ladrar(){
        return "Los perros ladran";
    }

    @Override
    public String caminar(double caminar) {
        if(caminar>100){
            return "El perro "+ getNombre() + " caminó más de 100 metros";
        }else{
           return "El perro "+ getNombre()+ " caminó menos de 100 metros";
        }
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

}
