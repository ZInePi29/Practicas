/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package runpractica3dispositivos;

/**
 *
 * @author denze
 */
public class Telefono extends DispositivosElectronicos implements IOperacionesAritmeticas{
    
    private String modelo;
    private String marca;
    private String color;
    
    public Telefono(){
        
    }
    
    public Telefono(String marca, String modelo, String color){
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }
    
    public void datosCelular(){
        System.out.println(this.marca + " " + this.modelo + " " + this. color);
    }
    
    @Override
    public String encender() {
        return "Telefono Encendido";
    }
    
    public String hacerLlamada(int num){
        return "Llamando " + num;
    }

    public String hacerLlamada(String contacto){
        return "Llamando " + contacto;
    }
    
    public String terminaLlamada(){
        return "La llamada ha terminado";
    }
    
    @Override
    public double suma(double a, double b) {
        return a+b;
    }

    @Override
    public double resta(double a, double b) {
        return a-b;
    }

    @Override
    public double multi(double a, double b) {
        return a*b;
    }

    @Override
    public double div(double a, double b) {
        return a/b;
    }
    
}
