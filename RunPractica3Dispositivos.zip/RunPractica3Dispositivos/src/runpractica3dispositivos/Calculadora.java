/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package runpractica3dispositivos;

/**
 *
 * @author denze
 */
public class Calculadora extends DispositivosElectronicos implements IOperacionesAritmeticas{
    
    private String modelo;
    private String marca;
    private String color;
    
    public Calculadora(){
        
    }
    
    public Calculadora(String marca, String modelo, String color){
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }
    
    public void datosCalculadora(){
        System.out.println(this.marca + " " + this.modelo + " " + this. color);
    }

    public double raiz(int a){
        return Math.sqrt(a);
    }
    
    @Override
    public String encender() {
        return "Calculadora Encendido";
    }
    
    @Override
    public double suma(double a, double b) {
        return a+b;
    }

    @Override
    public double resta(double a, double b) {
        return a-b;
    }

    @Override
    public double multi(double a, double b) {
        return a*b;
    }

    @Override
    public double div(double a, double b) {
        return a/b;
    }
    
}
