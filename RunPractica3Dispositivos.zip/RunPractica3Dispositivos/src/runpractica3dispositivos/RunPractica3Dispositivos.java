/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package runpractica3dispositivos;

/**
 *
 * @author denze
 */
public class RunPractica3Dispositivos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        Telefono samsung = new Telefono("Samsung", "A22", "Negro");
        samsung.datosCelular();
        System.out.println(samsung.encender());
        System.out.println(samsung.hacerLlamada("Mama"));
        System.out.println(samsung.hacerLlamada(122));
        System.out.println(samsung.terminaLlamada());
        System.out.println(samsung.suma(3, 5));
        System.out.println(samsung.resta(3, 5));
        System.out.println(samsung.multi(3, 5));
        System.out.println(samsung.div(3, 5));
        
        Calculadora casio = new Calculadora("Casio", "n12", "Azul");
        casio.datosCalculadora();
        System.out.println(casio.encender());
        System.out.println(casio.suma(10, 12));
        System.out.println(casio.resta(10, 12));
        System.out.println(casio.multi(10, 12));
        System.out.println(casio.div(10, 12));
        System.out.println(casio.raiz(16));
        
    }
    
}
