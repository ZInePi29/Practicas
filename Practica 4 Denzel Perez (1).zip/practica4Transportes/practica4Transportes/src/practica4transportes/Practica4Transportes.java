/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica4transportes;
import java.util.Scanner;
/**
 *
 * @author Dell
 */
public class Practica4Transportes {
    static Scanner tipo = new Scanner(System.in);
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Automovil electrico;
        Automovil gasolina;
        int x,carga;
        
        
        do{
            System.out.println("Tipo de auto:\n 1.Gasolina \n 2.Electrico");
            x = tipo.nextInt();
            if(x==1){
                System.out.println("Ingrese la cantidad de combustible con la que cuenta el coche");
                double gas = tipo.nextDouble();
                gasolina = new Automovil(gas);
            }
            else
                if(x==2){
                    
                    System.out.println("Ingrese el porcentaje de carga con la que cuenta el coche");
                    carga = tipo.nextInt();
                    electrico = new Automovil(carga);
                }
                else
                    System.out.println("Ingresa un valor válido");
                            
        }while(x!=1 && x!=2);
    }
    
}
