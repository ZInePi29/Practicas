/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica4transportes;

import vehiculos.Vehiculo;

public class Automovil extends Vehiculo{
    
    public Automovil (){

    }
    public Automovil (double gas){   
        this.encenderAutomovil(gas);
        this.avanzaAutomovil (gas);
    } 
    private void encenderAutomovil(double gas){
        if(gas > 1)
            System.out.println("Automovil Encendido");
        else
           System.out.println("No hay suficiente gasolina"); 
    }
    
    private void avanzaAutomovil(double gas){
        if(gas > 1 && gas < 10 || gas < 1)
            System.out.println("Nivel bajo de gasolina");
        else
           System.out.println("Hay suficiente gasolina"); 
    }
     
   public Automovil(int carga){
       this.encenderAutoElec(carga);
       this.avanzaAutoElec(carga);
   }
   
   private void encenderAutoElec(int carga){
       if(carga>=5)
           System.out.println("Coche encendido");
       else
           System.out.println("No hay carga suficiente");
   }
    
   private void avanzaAutoElec(int carga){
       if(carga>=5 && carga<=10)
           System.out.println("Cargue el coche");
       else
           System.out.println("Hay carga suficiente");
       
   }
    
}
