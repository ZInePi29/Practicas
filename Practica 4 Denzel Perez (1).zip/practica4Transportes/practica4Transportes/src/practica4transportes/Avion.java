package practica4transportes;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author denze
 */
import vehiculos.Vehiculo;

public class Avion extends Vehiculo {
    public Avion() {
    
    }
    
    public Avion(int combustible){
        this.encenderAvion(combustible);
        this.vuelaAvion(combustible);
    }
    
    private void encenderAvion(int combustible){
        if(combustible > 1)
            System.out.println("Avion Encendido");
        else
           System.out.println("No hay suficiente combustible");
    }
    private void vuelaAvion(int combustible){
        if(combustible > 1 && combustible < 35 || combustible < 1)
            System.out.println("Combustible bajo. No volar.");
        else
           System.out.println("Hay suficiente combustible, se puede volar.");
    }
}
