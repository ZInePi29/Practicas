/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica4transportes;

/**
 *
 * @author denze
 */
import vehiculos.Vehiculo;
public class Tren extends Vehiculo {
    
    public Tren() {
    
    }
    
    public Tren(int combustible){
        this.encenderTren(combustible);
        this.avanzaTren(combustible);
    }
    
    private void encenderTren(int combustible){
        if(combustible > 1)
            System.out.println("Tren Encendido");
        else
           System.out.println("No hay suficiente combustible");
    }
    private void avanzaTren(int combustible){
        if(combustible > 1 && combustible < 10 || combustible < 1)
            System.out.println("Combustible bajo");
        else
           System.out.println("Hay suficiente combustible");
    }

}
